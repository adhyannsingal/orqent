# Execution Engine

> **All content here is [Planned] unless marked otherwise.** No execution engine code exists yet (`app.domain.engine` is a documented placeholder package). This doc is the approved design that Phase 8 implements. See [architecture.md](architecture.md#11-execution-architecture-planned) and [decisions.md](decisions.md) (`ADR-007`, `ADR-013`–`ADR-015`).

The execution engine is the heart of Orqent: it turns a workflow definition + input into an ordered, durable, observable run. It is **framework-free** (`ADR-014`) — pure Python depending only on ports.

---

## 1. Responsibilities

The engine owns:
- **Orchestration** — running a workflow's nodes in the correct order.
- **State & lifecycle** — transitioning executions and steps through their states.
- **Durability** — persisting every step so a crashed run can resume.
- **Reliability** — retries, timeouts, cancellation.
- **Context passing** — feeding one node's output into the next.

The engine does **not** own: HTTP (that's the API), the actual LLM call (that's the `AgentRunner` port → [langchain.md](langchain.md)), the async transport (that's the `TaskQueue`), or persistence mechanics (that's repositories via the Unit of Work). This separation is what keeps it testable with mock ports.

---

## 2. AgentRunner abstraction (`ADR-013`)

The engine executes a single agent node through the **`AgentRunner` port**:

```
AgentRunner.run(agent_version, input, context) -> AgentResult
```

- `agent_version` — the immutable, pinned config (provider, model, prompt, parameters).
- `input`/`context` — resolved from upstream node outputs.
- Returns normalized output + token usage.

Two adapters (both **[Planned]**): `MockAgentRunner` (deterministic, used to build/test the engine in Phase 8) and `LangChainAgentRunner` (Phase 9, the only LangChain importer). Because the engine depends only on the port, the mock→LangChain switch is one wiring line in the container. Full boundary rules: [langchain.md](langchain.md).

---

## 3. Execution states

```mermaid
stateDiagram-v2
    [*] --> PENDING
    PENDING --> QUEUED: enqueued
    QUEUED --> RUNNING: worker claims (atomic)
    RUNNING --> SUCCEEDED: all nodes done
    RUNNING --> FAILED: unrecoverable node failure
    RUNNING --> CANCELLING: cancel requested
    CANCELLING --> CANCELLED
    RUNNING --> TIMED_OUT: deadline exceeded
    RUNNING --> WAITING: hits wait/approval node (Future)
    WAITING --> RUNNING: event resolves
    FAILED --> QUEUED: retry (new attempt)
```

Steps mirror this at node granularity: `PENDING → RUNNING → (SUCCEEDED | FAILED | RETRYING | SKIPPED | TIMED_OUT | CANCELLED)`. States are stored as `VARCHAR` (never MySQL `ENUM`).

---

## 4. Workflow execution lifecycle

```mermaid
sequenceDiagram
    autonumber
    actor Client
    participant API as FastAPI route
    participant ES as ExecutionService
    participant DB as MySQL (UoW/repos)
    participant Q as TaskQueue port
    participant W as Worker
    participant ENG as Execution Engine
    participant AR as AgentRunner port

    Client->>API: POST /workflows/{id}/execute {input, idempotency_key}
    API->>ES: start_execution(user, wf_id, input)
    ES->>DB: load published workflow_version (tenant-scoped)
    ES->>DB: INSERT executions(status=PENDING)
    ES->>Q: enqueue(execution_public_id)
    ES-->>API: execution_public_id
    API-->>Client: 202 Accepted + Location /executions/{id}

    Note over W,ENG: asynchronous, off the request path
    W->>Q: dequeue()
    W->>DB: atomic claim QUEUED→RUNNING (guarded)
    W->>ENG: run(execution_id)
    ENG->>DB: load graph, build linear order
    loop each node A→B→C→D
        ENG->>DB: INSERT execution_steps(RUNNING, attempt)
        ENG->>DB: pin agent_version_id
        ENG->>AR: run(agent_version, input+context)
        AR-->>ENG: output + tokens
        ENG->>DB: UPDATE step(SUCCEEDED, output, tokens, latency)
        ENG->>DB: INSERT execution_logs(node finished)
        Note over ENG: on failure → retry w/ backoff or FAILED
    end
    ENG->>DB: UPDATE executions(SUCCEEDED, output, finished_at)

    Client->>API: GET /executions/{id} (poll)
    API-->>Client: status + steps + logs
```

The trigger returns `202` immediately; the client polls `GET /executions/{id}`. (`[Future]`: WebSocket streaming instead of polling.)

---

## 5. Linear workflow design for V1 (`ADR-007`)

V1 executes a straight chain: `Agent A → Agent B → Agent C → Agent D`. Each node has at most one predecessor and one successor, enforced at the DB level by two unique constraints on `workflow_edges` (see [database.md](database.md#3-planned-schema-by-phase)). The V1 scheduler is a simple linear traversal: start at the source node, run it, follow its single outgoing edge, repeat.

**Context passing:** the engine keeps an in-memory context of `{node_key: output}`, and each edge's `data_mapping` declares how an upstream output binds to the next node's input. Explicit and inspectable — no hidden global blackboard.

---

## 6. Future DAG support **[Future]**

Branching, conditional edges, parallel fan-out/fan-in, and merges are deferred. The schema is already DAG-ready; enabling it is:
1. Drop the two `workflow_edges` linearity unique constraints (one migration).
2. Replace the linear traversal with topological scheduling (a scheduler change behind the same interface).
3. Add `condition`/`transform` node types (new `type` values + handlers, no schema change).

Genuine loops would be modelled as bounded iteration inside a node or an explicit `loop` node with a max-iterations guard, keeping the top-level graph acyclic.

---

## 7. Reliability **[Planned]**

- **Retries** — per-node policy (`max_attempts`, exponential backoff + jitter, `retry_on` error classes). Each attempt is a new `execution_steps` row (history preserved).
- **Timeouts** — per-node (wrap the `AgentRunner` call) and per-execution deadline → `TIMED_OUT`.
- **Cancellation** — cooperative: a cancel request flips state to `CANCELLING`; the engine checks between nodes (the safe cancellation points) → `CANCELLED`.
- **Failure recovery / resume** — because every step is persisted, a crashed worker's execution is re-claimed and resumes from the first incomplete node; succeeded steps are skipped. Requires idempotent step execution (at-least-once semantics). A reaper re-queues executions stuck in `RUNNING` past a heartbeat.

---

## 8. Queue & worker **[Planned]** (`ADR-015`)

<a name="queue--worker-planned"></a>
- **`TaskQueue` port** — enqueue/dequeue of execution ids. V1 adapter: a **durable DB-backed in-process queue** (the database is the queue). Not FastAPI `BackgroundTasks` (no persistence/retry/visibility).
- **Worker runtime** — a loop that dequeues, performs the **atomic `QUEUED→RUNNING` claim** (a guarded `UPDATE ... WHERE status='QUEUED'` so two workers never double-run), invokes the engine, and heartbeats.
- **Reaper** — re-queues stuck executions.
- **[Future]** — swap the adapter for Celery/Redis; workers scale horizontally with the same engine.

---

## Cross-references
- Ports & isolation: [architecture.md](architecture.md#4-ports-and-adapters), [langchain.md](langchain.md)
- Tables used: [database.md](database.md)
- Phase timing: [roadmap.md](roadmap.md)
- Decisions: [decisions.md](decisions.md) (`ADR-007`, `ADR-014`, `ADR-015`)
