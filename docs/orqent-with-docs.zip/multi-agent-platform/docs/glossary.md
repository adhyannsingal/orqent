# Glossary

Canonical terms. Use these spellings/casings everywhere (code, comments, docs) for consistency.

| Term | Definition |
|------|------------|
| **Orqent** | This project: a backend platform for building and running multi-agent AI workflows. The Python package is `app`. |
| **Agent** | A configured, reusable unit of LLM behaviour (provider + model + prompt + parameters). Identity is stable; behaviour lives in an immutable **agent version**. **[Planned]** |
| **Agent version** | An immutable snapshot of an agent's configuration (table `agent_versions`). Executions pin the exact version used, for reproducibility. **[Planned]** |
| **AgentRunner** | The domain **port** for executing one agent step: `run(agent_version, input, context) -> AgentResult`. The single seam LangChain hides behind. **[Planned]** — [langchain.md](langchain.md) |
| **Adapter** | A concrete implementation of a **port**, living in `app.infrastructure`. |
| **ADR** | Architecture Decision Record — a numbered decision in [decisions.md](decisions.md). |
| **Container** | The DI composition root (`app.container.Container`) — the only place mapping abstractions to concretions. **[Implemented]** |
| **Correlation ID** | Per-request/execution identifier (`X-Correlation-ID`) stamped on every log line. **[Implemented]** |
| **DAG** | Directed Acyclic Graph. V1 workflows are linear; DAG/branching is **[Future]**. |
| **Domain** | The pure core (`app.domain`): entities, value objects, ports, engine. Imports no framework/vendor/driver. |
| **Execution** | One run of a workflow version (table `executions`), with a lifecycle and status. **[Planned]** |
| **Execution engine** | The framework-free component that runs a workflow's nodes, persists steps, and handles retries/timeouts/cancellation. `app.domain.engine`. **[Planned]** — [execution-engine.md](execution-engine.md) |
| **Execution step** | One node's execution within a run (table `execution_steps`); retries create new rows. **[Planned]** |
| **Execution log** | User-facing trace of a run (table `execution_logs`), distinct from application logs. **[Planned]** |
| **Generated column** | `users.email_active`, a virtual MySQL column = `IF(deleted_at IS NULL, email, NULL)`, carrying the live-email unique index (`ADR-005`). **[Implemented]** |
| **LLMProvider** | The domain **port** for a raw model call (normalized). First adapter is a mock (no keys). **[Planned]** |
| **Mixin** | A single-concern column bundle (`CreatedAtMixin`, `TimestampMixin`, `PublicIdMixin`, `TenantMixin`). **[Implemented]** |
| **Organization** | The tenant (table `organizations`); every owned row scopes to one. **[Implemented]** |
| **Port** | An abstract interface in `app.domain.ports` that the domain depends on; implemented by an **adapter**. |
| **Public ID** | The externally exposed ULID (`public_id`, `CHAR(26)`); internal `id` (BIGINT) is never exposed (`ADR-004`). **[Implemented]** |
| **Repository** | The only code that talks to MySQL, one per aggregate, returning ORM models, scoping by `organization_id`. **[Planned]** |
| **Soft delete** | Marking a row deleted via `deleted_at` instead of removing it. **[Implemented]** on `users`. |
| **TaskQueue** | The domain **port** for durable async hand-off; V1 adapter is a DB-backed in-process queue (`ADR-015`). **[Planned]** |
| **Tenant** | See **Organization**. Multi-tenancy is a column from day one (`ADR-016`). |
| **ULID** | Universally Unique Lexicographically Sortable Identifier; Orqent's public-id format. |
| **Unit of Work (UoW)** | The transaction boundary. Port `UnitOfWork` (domain) + `SqlAlchemyUnitOfWork` (infra). **[Implemented]** — [architecture.md](architecture.md#9-unit-of-work-implemented) |
| **VectorStore** | The domain **port** for vector upsert/query, implemented by a Chroma adapter. **[Planned]** |
| **Workflow** | A user-defined composition of agents (table `workflows`); behaviour lives in an immutable **workflow version**. **[Planned]** |
| **Workflow version** | Immutable snapshot of a workflow graph (table `workflow_versions`); executions bind to it. **[Planned]** |
| **Node / Edge** | Units and connections of a workflow graph (`workflow_nodes`, `workflow_edges`). Edges carry control flow + `data_mapping`. **[Planned]** |

### Status labels (used across all docs)
- **[Implemented]** — exists in code today.
- **[Planned]** — designed & approved, scheduled for a specific phase.
- **[Future]** — post-V1; direction agreed, not yet designed in detail.

---

Cross-references: [architecture.md](architecture.md) · [decisions.md](decisions.md) · [database.md](database.md) · [execution-engine.md](execution-engine.md) · [langchain.md](langchain.md) · [roadmap.md](roadmap.md)
