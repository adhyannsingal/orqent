# Database

MySQL 8 (InnoDB, `utf8mb4`). Async access via `asyncmy` (`ADR-001`). This doc covers the **implemented** foundation schema and the **planned** full schema, plus the migration strategy. Decisions are cited as `ADR-n` from [decisions.md](decisions.md).

> The complete design package (full ER diagram of all 22 current + planned tables, every column, and the cross-phase migration plan) is preserved separately as the approved design artifact. This doc summarises it and stays in sync with the code.

---

## 1. Conventions (all `[Implemented]`)

- **Internal PK:** `id BIGINT UNSIGNED AUTO_INCREMENT` — compact, fast joins, never exposed. Helper: `big_int_pk()`.
- **Public ID:** `public_id CHAR(26)` ULID, unique, the only id in the API (`ADR-004`). Mixin: `PublicIdMixin`, generator: `new_public_id()`.
- **Timestamps:** `created_at`/`updated_at` `DATETIME(6)`, app-managed UTC (`ADR-017`). Mixins: `CreatedAtMixin`, `TimestampMixin`.
- **Tenancy:** `organization_id` on owned tables (`ADR-016`). Mixin: `TenantMixin` (FK, `ON DELETE CASCADE`, indexed).
- **Naming convention** (`ADR-006`): `pk_%(table)s`, `uq_%(table)s_%(cols)s`, `fk_%(table)s_%(cols)s_%(ref)s`, `ix_%(table)s_%(cols)s`, `ck_%(table)s_%(name)s`. Set on `Base.metadata` before any table.
- **Enums:** `VARCHAR` + Python enum, never native MySQL `ENUM` (avoids table-rebuild `ALTER`s).
- **Charset/collation:** `utf8mb4` / `utf8mb4_0900_ai_ci`; to be pinned explicitly in migration `0001` (MySQL 8 server default already matches — see [technical debt](roadmap.md#technical-debt)).

---

## 2. Implemented models (Phase 2)

Four foundation tables exist in `app.infrastructure.db.models`:

```mermaid
erDiagram
    ORGANIZATIONS ||--o{ USERS : has
    USERS ||--o{ USER_ROLES : ""
    ROLES ||--o{ USER_ROLES : ""
    ORGANIZATIONS {
        bigint id PK
        char public_id UK
        string name
        string slug UK
    }
    USERS {
        bigint id PK
        bigint organization_id FK
        char public_id UK
        string email
        string email_active UK "generated"
        string password_hash
        bool is_active
        datetime deleted_at
    }
    ROLES {
        bigint id PK
        string name UK
        string description
    }
    USER_ROLES {
        bigint user_id PK
        bigint role_id PK
    }
```

### `organizations` — tenant root (`PublicIdMixin`, `TimestampMixin`)
`id` PK · `name` · `slug` (unique) · `public_id` (unique) · timestamps. Relationship `users` (one-to-many, `cascade="all, delete-orphan"`, `passive_deletes=True`). **Why each field:** `name` = display; `slug` = URL-safe unique handle; `public_id` = external id.

### `users` — auth identity (`PublicIdMixin`, `TenantMixin`, `TimestampMixin`)
`id` PK · `organization_id` FK (`CASCADE`, indexed) · `email` (indexed, for login) · **`email_active`** (virtual generated column, unique — the live-email uniqueness mechanism, `ADR-005`) · `password_hash` (Argon2id only) · `is_active` · `email_verified_at` · `deleted_at` (soft delete; drives `email_active`) · `public_id` · timestamps. Relationships: `organization`, `user_roles` (`cascade`, `passive_deletes`).

### `roles` — global RBAC catalog (`TimestampMixin`)
`id` PK · `name` (unique) · `description`. No `organization_id`/`public_id` (global, referenced by stable `name`). Relationship `user_roles` (no delete cascade — `role_id` is `RESTRICT`).

### `user_roles` — assignment (`CreatedAtMixin` only)
Composite PK `(user_id, role_id)` · `user_id` FK (`CASCADE`) · `role_id` FK (`RESTRICT`, indexed for reverse lookup). Only `created_at` (an assignment is created, not edited). **No `organization_id`** — derivable from `users` (avoids redundancy).

### Cascade summary (implemented)
| FK | On delete | Reason |
|----|-----------|--------|
| `users.organization_id` | CASCADE | tenant purge removes its users |
| `user_roles.user_id` | CASCADE | deleting a user removes its assignments |
| `user_roles.role_id` | RESTRICT | can't delete a role still assigned |

<a name="generated-column-email-uniqueness"></a>
### Generated-column email uniqueness (`ADR-005`)
```sql
email_active VARCHAR(255)
  GENERATED ALWAYS AS (IF(deleted_at IS NULL, email, NULL)) VIRTUAL,
UNIQUE KEY uq_users_email_active (email_active)
```
Live rows carry the real email (unique); soft-deleted rows collapse to `NULL` (MySQL treats NULLs as distinct, so the address frees up). Emulates a Postgres partial unique index, which MySQL lacks.

---

## 3. Planned schema (by phase)

Designed and approved; created in the migration for each phase (`ADR-012`). Cascade philosophy: `CASCADE` from `organizations` for clean tenant purge; `RESTRICT` guards in-use config/catalog rows; `SET NULL` for optional provenance.

| Phase | Tables | Notes |
|-------|--------|-------|
| 3 | `refresh_tokens` | hashed token, `token_family_id`, rotation/reuse (`ADR-010`) |
| 4 | `provider_types`, `provider_configs`, `prompt_templates`, `agents`, `agent_versions` | providers pulled into Phase 4 to satisfy `agent_versions` FK; `api_key_encrypted` nullable (mock providers); circular FK `agents.active_version_id` via `ALTER` |
| 6 | `workflows`, `workflow_versions`, `workflow_nodes`, `workflow_edges` | immutable versions; two linearity unique constraints on edges (`ADR-007`) |
| 8 | `executions`, `execution_steps`, `execution_logs` | append-only history; steps pin `agent_version_id` for reproducibility |
| 10 | `memory_collections`, `documents`, `document_chunks` | Chroma metadata mirror (`ADR-003`); back-fill `agent_versions.memory_collection_id` FK |
| 11 | `tools`, `agent_tools` | tool catalog + grants; back-fill `workflow_nodes.tool_id` FK |

**[Future]** tables: `memberships` (multi-org, ADR-011), fine-grained `permissions`/`role_permissions`.

Key planned design points (see [architecture.md](architecture.md) and [execution-engine.md](execution-engine.md)):
- **Versioning:** `agent_versions` and `workflow_versions` are immutable; edits create new versions (reproducibility).
- **Reproducibility pinning:** `workflow_nodes` reference agent *identity*; `execution_steps` record the concrete `agent_version_id` that ran.
- **Linearity at the DB level:** `workflow_edges` gets `uq(version, source_node)` + `uq(version, target_node)` in V1; dropping them enables branching later.

---

## 4. Migration strategy **[Planned]** (`ADR-012`)

Tooling is configured (`[Implemented]`): `alembic.ini` (no credentials; URL injected from `Settings` in `migrations/env.py`), async `env.py` (runs via `connection.run_sync`, `compare_type`/`compare_server_default` on, imports the models package so `target_metadata` is complete), timestamped revision filenames. **No migrations generated yet** (per phase discipline).

Rules:
1. **Naming convention exists before `0001`** (already true, `ADR-006`).
2. **Every autogenerated revision is human-reviewed** — Alembic misses generated-column expressions, server-default changes, and some index renames.
3. **Circular FKs** (`active_version_id`): create both tables, then `ALTER` to add the nullable back-reference FK.
4. **Deferred FKs** (`memory_collection_id`, `tool_id`): add the column nullable in its phase, add the FK constraint in the later phase when the target table exists.
5. **`0001_foundation`** will create the four foundation tables, the generated `email_active` column + unique index, seed `roles` (`owner`/`admin`/`member`/`viewer`), and pin charset/collation.
6. **Future** `enable_branching` migration drops the two `workflow_edges` linearity constraints — no structural change.

Commands: see [development-guide.md](development-guide.md#alembic-workflow).

---

## Cross-references
- Why these choices: [decisions.md](decisions.md)
- How the schema is used at runtime: [execution-engine.md](execution-engine.md)
- Setup & migration commands: [development-guide.md](development-guide.md)
- Roadmap status: [roadmap.md](roadmap.md)
