# Mentor Notes

Guidance received from the mentor and the decisions approved during review. This is the "why we're allowed to / required to" record; the formal decisions are in [decisions.md](decisions.md).

---

## 1. Mentor-mandated constraints

These came directly from the mentor and are **non-negotiable** without re-consulting them:

1. **LangChain for orchestration, but isolated.** LangChain is introduced only inside the execution layer, behind the `AgentRunner` port. The rest of the backend stays completely independent; replacing LangChain must require minimal change. → `ADR-013`, [langchain.md](langchain.md).
2. **Orchestration stays framework-independent.** Orqent owns the execution engine, state, persistence, and history; do not couple business logic to LangChain. → `ADR-014`, [execution-engine.md](execution-engine.md).
3. **Linear workflows for V1.** Branching/conditional/DAG execution is deferred — but preserve abstractions that make branching easy later **if free**. This is why the node/edge model and DB-level linearity constraints exist. → `ADR-007`.
4. **No real LLM integration yet.** No API keys. The execution layer must run on mock/fake providers first and swap in real providers later without architectural change. → `LLMProvider`/`AgentRunner` ports, mock adapters.
5. The engineer (you) owns the entire backend: FastAPI, architecture, auth, MySQL, SQLAlchemy, Alembic, repository pattern, service layer, API layer, ChromaDB integration, logging, execution history/records, agent & workflow CRUD, document management, and background execution infrastructure.

---

## 2. The seven approved design decisions (Phase 2 review)

Approved during the database design review and now applied in code/schema:

| # | Decision | Where |
|---|----------|-------|
| 1 | **Async SQLAlchemy** (`mysql+asyncmy`) | `ADR-001` |
| 2 | **Incremental migrations** (one table set per phase) | `ADR-012` |
| 3 | **Global-unique email, one org per user** | `ADR-011` |
| 4 | **ORM models as anemic data carriers** (no mapping layer) | `ADR-008` |
| 5 | **ULID public IDs, `CHAR(26)`** | `ADR-004` |
| 6 | **Soft delete via generated-column email uniqueness** | `ADR-005` |
| 7 | **Renames:** `sessions`→`refresh_tokens`, `agent_configs`→`agent_versions`, `providers`→`provider_types` | applied in [database.md](database.md) |

Additional approved refinements from that review:
- **Providers moved into Phase 4** (from Phase 5) to satisfy the `agent_versions → provider_configs` FK; Phase 5 is code-only. → [roadmap.md](roadmap.md), [database.md](database.md).
- **DB-level linearity enforcement** on `workflow_edges` (two unique constraints, dropped later to enable branching). → `ADR-007`.
- **Reproducibility pinning:** workflow nodes reference agent identity; executions pin the concrete `agent_version`. → [database.md](database.md).

---

## 3. Open items to confirm (before the relevant phase)

Carried forward from reviews; revisit with the mentor when the phase arrives:

- **Async vs sync** was decided async — confirm still fine at implementation time.
- **Secret storage** for real provider keys (Phase 9+): app-layer AES-GCM vs a `SecretCipher` port wrapping KMS/Vault if EY provides one.
- **In-process queue durability** (`ADR-015`): confirm the DB-backed claim approach meets the reliability bar before Phase 8 relies on it for resume.
- **ULID storage** `CHAR(26)` vs `BINARY(16)` — confirm before it's load-bearing across many tables.
- **Single-tenant launch**: columns/scoping are in from day one (`ADR-016`); confirm whether org-management endpoints are exposed in V1.

---

## Cross-references
- Formal decisions: [decisions.md](decisions.md)
- Roadmap & phase order: [roadmap.md](roadmap.md)
- LangChain boundary: [langchain.md](langchain.md)
