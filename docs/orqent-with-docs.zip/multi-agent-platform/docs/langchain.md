# LangChain Integration & Isolation

> **Status: [Planned].** No LangChain code exists yet. This doc defines the boundary that Phase 9 must respect. Decision: `ADR-013`. Related: [execution-engine.md](execution-engine.md), [architecture.md](architecture.md#4-ports-and-adapters).

---

## 1. Why LangChain is isolated

LangChain is used for agent execution, but the rest of Orqent must remain **completely independent** of it, so that replacing it later requires minimal change. This is a hard architectural rule from the mentor (see [mentor-notes.md](mentor-notes.md)).

The reasons:
- **Orchestration is ours, not LangChain's.** Workflow sequencing, execution state, retries, cancellation, and — critically — the durable execution **history** in MySQL are Orqent's responsibility. LangChain would not persist to our schema or own our lifecycle.
- **Replaceability.** LLM tooling churns fast. Confining LangChain to one adapter means a swap (to another framework, or direct SDK calls) touches one file.
- **Testability.** The execution engine is built and tested against a mock, with no heavy dependency in the loop.

---

## 2. The boundary: the `AgentRunner` port

LangChain lives behind exactly one port:

```
AgentRunner.run(agent_version, input, context) -> AgentResult
```

```mermaid
flowchart LR
    ENG[Execution Engine - pure] -->|depends on| PORT{{AgentRunner port - domain}}
    PORT -. implemented by .- MOCK[MockAgentRunner]
    PORT -. implemented by .- LC[LangChainAgentRunner]
    LC --> LANGCHAIN[(langchain)]
    style LC fill:#f8d7e8,stroke:#c2508a
    style LANGCHAIN fill:#f8d7e8,stroke:#c2508a
```

- The **engine** depends on the `AgentRunner` port only.
- `LangChainAgentRunner` (in `app.infrastructure.llm`) is **the only module in the entire codebase permitted to import `langchain`**.
- Switching mock → LangChain is one wiring change in [`Container`](architecture.md#8-dependency-injection-container-implemented).

The `infrastructure/llm/__init__.py` docstring already records this rule in the code.

---

## 3. What LangChain may and may not do

**May (inside `LangChainAgentRunner` only):**
- Build and invoke a single agent runnable (LLM + prompt + optional memory/tools) for one node.
- Translate between Orqent's normalized types and LangChain's.

**May not:**
- Own workflow orchestration, ordering, or scheduling (that's the engine).
- Persist anything to MySQL or define our execution history.
- Leak LangChain types across the port boundary — the engine and services see only Orqent's normalized `AgentResult`.
- Be imported anywhere outside `app.infrastructure.llm`.

---

## 4. Relationship to `LLMProvider`

There are two layers of abstraction (both **[Planned]**):
- **`LLMProvider`** — the low-level "call a model" port. First adapter is `MockLLMProvider` (no API keys, no network). Real providers (OpenAI/Anthropic/Gemini/local) come later.
- **`AgentRunner`** — the higher-level "run one agent step" port that LangChain implements, using an `LLMProvider` underneath.

This lets Orqent run end-to-end on mocks first (Phases 5–8) and drop in LangChain (Phase 9) without the engine noticing.

---

## 5. Swap-out story

If LangChain is ever removed:
1. Write a new `AgentRunner` adapter (direct SDK calls, or another framework).
2. Change one line in the container wiring.
3. Everything else — engine, services, API, schema, history — is untouched.

That single-file blast radius is the entire point of `ADR-013`.

---

## Cross-references
- Engine that consumes the port: [execution-engine.md](execution-engine.md)
- Port/adapter model: [architecture.md](architecture.md#4-ports-and-adapters)
- Rule origin: [mentor-notes.md](mentor-notes.md), [decisions.md](decisions.md) (`ADR-013`)
