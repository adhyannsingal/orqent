# Coding Standards

Rules every change must follow. These are enforced by tooling where possible and by review otherwise. For *how* to do common tasks see [development-guide.md](development-guide.md); for *why* see [decisions.md](decisions.md).

---

## 1. Single Responsibility Principle (SRP)

SRP is a hard requirement in this codebase.
- **One module, one concern.** e.g. `naming.py` (convention), `identifiers.py` (ULID), `engine.py` (engine construction), `session.py` (session factory) are deliberately separate.
- **One class, one purpose.** The Unit of Work manages a transaction and nothing else; mixins each add one column concern (`CreatedAtMixin` vs `TimestampMixin` are split so an immutable `user_roles` row doesn't carry a meaningless `updated_at`).
- **One method, one use case** (services, Planned).
- If a "util" grows business meaning, promote it to a domain service. If a class needs "and" to describe it, split it.

---

## 2. Dependency rule

Dependencies point inward; the domain depends on nothing outward. Full statement and diagram: [architecture.md](architecture.md#5-dependency-rule). In short:
- `app.domain` imports no framework, no SQLAlchemy, no LangChain, no driver, and none of `app.api`/`app.services`/`app.infrastructure`.
- Only `app.infrastructure` imports SQLAlchemy, drivers, LangChain, Chroma.
- Only `app.container` maps abstractions to concretions.

<a name="layer-rules"></a>
### Per-layer "never put here"
| Layer | Never contains |
|-------|----------------|
| API (`app.api`) | business logic, SQL, transactions, vendor SDKs |
| Services (`app.services`) | SQL, FastAPI request/response objects, vendor SDKs |
| Domain (`app.domain`) | I/O, DB, HTTP, framework/vendor imports |
| Repositories (Planned) | business rules, commit/rollback decisions, HTTP, cross-aggregate orchestration |
| Infrastructure | use-case orchestration, HTTP concerns |

---

## 3. Typing

- **MyPy strict** across `src` (`disallow_untyped_defs`, `no_implicit_optional`, etc.). CI fails on any error.
- Modern syntax: `X | None`, `list[X]`, PEP 695 generics (`class DataResponse[T]`), `StrEnum`.
- Every function is fully typed. Prefer `Annotated[...]` FastAPI dependencies over `Depends()` defaults (avoids `B008`).

---

## 4. Formatting & linting

- **Ruff** for both format and lint (config in `pyproject.toml`; no separate files). Rule set includes pycodestyle, pyflakes, isort, naming, pyupgrade, bugbear, builtins, comprehensions, simplify, async, pylint.
- 100-char lines, `py312` target, `known-first-party = ["app"]`.
- Run `ruff format .` and `ruff check --fix .` before committing.

---

## 5. Docstrings & comments

- Every module opens with a docstring stating its responsibility and how it fits the architecture (see existing files as the template).
- Comments explain **why**, not what. ORM field comments justify each column's existence (see `models/user.py`).
- Placeholder packages carry a docstring describing what will live there and the rules for it (e.g. `infrastructure/llm/__init__.py` records the LangChain-isolation rule).

---

## 6. Naming

- Tables/columns follow the metadata naming convention (`ADR-006`, [database.md](database.md)).
- Public identifiers are ULIDs called `public_id`; internal PKs are `id` and are never exposed.
- Terminology must match [glossary.md](glossary.md) exactly (e.g. "Unit of Work", "AgentRunner", "port", "adapter", "workflow version").

---

## 7. Error handling philosophy

<a name="error-handling-philosophy"></a>
- Domain and service code raise **domain exceptions** (`app.domain.errors.AppError` and subclasses: `ValidationError`, `AuthenticationError`, `AuthorizationError`, `NotFoundError`, `ConflictError`, `DomainRuleError`, `InfrastructureError`). They know nothing about HTTP.
- Business code **never** raises `fastapi.HTTPException`.
- The API layer (`app.api.errors`) is the **only** place that maps exceptions to HTTP status codes and the single `ErrorResponse` envelope (`{error: {code, message, correlation_id, details[]}}`). Registering the base `AppError` covers all subclasses (Starlette walks the MRO).
- Every error response carries the `correlation_id`. Unexpected exceptions → 500, logged with a stack trace, generic body (no internals leaked).

---

## 8. Logging philosophy

<a name="logging-philosophy"></a>
- **Structured** (structlog): JSON in production, colourised console locally (`APP_LOG_JSON`). One consistent format for our logs and uvicorn's (stdlib is routed through the same pipeline).
- **Correlated:** every line carries the `correlation_id` (and, during a request, path/method) via context vars.
- **Log:** state transitions, timings, error classes, decisions.
- **Never log:** passwords, hashes, tokens, provider API keys, full sensitive prompts, PII. (Redaction is a Phase 12 hardening item.)
- Three streams (Planned as features arrive): application/debug logs, the user-facing **execution log** (`execution_logs` table), and **audit logs**.

---

## 9. Testing philosophy

<a name="testing-philosophy"></a>
- **Pyramid:** many fast unit tests, fewer integration, minimal e2e.
- **No hidden I/O in unit tests.** Current tests assert DB *metadata/DDL* structurally and exercise the Unit of Work on in-memory SQLite (`StaticPool`) — **no MySQL required**, so CI is fast and hermetic.
- The **execution engine** (Phase 8) will be tested against a **mock `AgentRunner`**: ordering, retries, timeout, cancellation, and resume-after-crash — with zero external dependencies.
- **Contract tests** for adapters: one suite run against every `LLMProvider`/`AgentRunner` implementation to guarantee they honour the port.
- Every use case (services) gets tests with real repositories on a test DB + faked provider/queue ports.
- How to run and structure tests: [development-guide.md](development-guide.md#testing).

---

## 10. Async rules

- Everything on the request/execution path is async.
- Sessions use `expire_on_commit=False` (no post-commit blocking reloads).
- Never do blocking I/O on the event loop; the engine stays framework-free and calls async ports.

---

## 11. Commands before every commit

```bash
ruff format .
ruff check --fix .
mypy src
pytest
# or, equivalently, the hooks:
pre-commit run --all-files
```
All four must pass. CI runs the same gates (`.github/workflows/ci.yml`).

---

## Cross-references
- Architecture & dependency rule: [architecture.md](architecture.md)
- Rationale: [decisions.md](decisions.md)
- Task recipes: [development-guide.md](development-guide.md)
- Permanent AI context: [../CLAUDE.md](../CLAUDE.md)
